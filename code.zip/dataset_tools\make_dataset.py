import argparse
import glob
import json
import os
from typing import List
import numpy as np
import pandas as pd

from dataset_tools.fen_utils import PIECE_TO_ID, fen_board_to_64_labels, idx_to_square_name


def pick_frame_column(columns: List[str]) -> str:
    candidates = ["from_frame", "frame_id", "to_frame"]
    for c in candidates:
        if c in columns:
            return c
    raise ValueError(f"No frame id column found; expected one of {candidates}, got {columns}")


def infer_frame_path(game_dir: str, frame_id: int) -> str | None:
    patterns = [
        os.path.join(game_dir, "tagged_images", f"frame_{frame_id:06d}.jpg"),
        os.path.join(game_dir, "tagged_images", f"frame_{frame_id:06d}.png"),
    ]
    for p in patterns:
        if os.path.exists(p):
            return p
    return None


def build_manifest(
    data_root: str,
    out_root: str,
    train_ratio: float = 0.8,
    val_ratio: float = 0.0,
    skip_missing: bool = True,
    seed: int = 42,
    detect_board: bool = False,
    warp_size: int = 800,
) -> pd.DataFrame:
    os.makedirs(out_root, exist_ok=True)

    classes_path = os.path.join(out_root, "classes.json")
    with open(classes_path, "w", encoding="utf-8") as f:
        json.dump({str(v): k for k, v in PIECE_TO_ID.items()}, f, indent=2)

    game_dirs = sorted([d for d in glob.glob(os.path.join(data_root, "*")) if os.path.isdir(d)])
    if not game_dirs:
        raise FileNotFoundError(f"No game directories found under {data_root}")

    rows = []
    
    # Process ALL games (fixed indentation)
    for game_dir in game_dirs:
        game_id = os.path.basename(game_dir)

        csv_candidates = glob.glob(os.path.join(game_dir, "*.csv"))
        if not csv_candidates:
            print(f"Warning: No CSV found in {game_dir}, skipping")
            continue
        game_csv = csv_candidates[0]

        df = pd.read_csv(game_csv)
        if "fen" not in df.columns:
            print(f"Warning: No 'fen' column in {game_csv}, skipping")
            continue

        frame_col = pick_frame_column(list(df.columns))

        for _, r in df.iterrows():
            frame_id = int(r[frame_col])
            fen = str(r["fen"])
            labels64 = fen_board_to_64_labels(fen)

            frame_path = infer_frame_path(game_dir, frame_id)
            if frame_path is None:
                if skip_missing:
                    continue
                raise FileNotFoundError(f"Frame not found: {game_dir}/frame_{frame_id}")

            if detect_board:
                try:
                    from dataset_tools.board_detect_and_warp import process_image as warp_once
                except ImportError as e:
                    raise ImportError("OpenCV required for --detect_board") from e

                warp_dir = os.path.join(out_root, "warped", game_id)
                os.makedirs(warp_dir, exist_ok=True)
                stem, _ = os.path.splitext(os.path.basename(frame_path))
                warped_path = os.path.join(warp_dir, f"{stem}_warp.png")
                try:
                    warp_once(frame_path, warped_path, out_debug=None, out_size=warp_size)
                    frame_path = warped_path
                except Exception as exc:
                    if skip_missing:
                        print(f"Warning: Warp failed for {game_id} frame {frame_id}: {exc}")
                        continue
                    raise

            for square_idx in range(64):
                row_idx = square_idx // 8
                col_idx = square_idx % 8
                rows.append({
                    "frame_path": frame_path,
                    "game_id": game_id,
                    "frame_id": frame_id,
                    "square_idx": square_idx,
                    "row": row_idx,
                    "col": col_idx,
                    "square_name": idx_to_square_name(square_idx),
                    "label_id": labels64[square_idx],
                })

    # FIXED: These lines are now OUTSIDE the loop
    if train_ratio + val_ratio > 1:
        raise ValueError("train_ratio + val_ratio must be <= 1.0")
    
    test_ratio = 1 - train_ratio - val_ratio
    if test_ratio <= 0:
        raise ValueError("test_ratio must be positive")

    manifest = pd.DataFrame(rows)
    
    if len(manifest) == 0:
        raise ValueError("No valid data found!")

    # Game-level split (not frame-level)
    games = manifest["game_id"].unique()
    print(f"Found {len(games)} games: {sorted(games)}")
    
    rng = np.random.RandomState(seed)
    rng.shuffle(games)

    n_games = len(games)
    n_train_games = int(train_ratio * n_games)
    n_val_games = int(val_ratio * n_games)

    train_games = set(games[:n_train_games])
    val_games = set(games[n_train_games : n_train_games + n_val_games])
    test_games = set(games[n_train_games + n_val_games :])

    print(f"Train games: {sorted(train_games)}")
    print(f"Val games:   {sorted(val_games)}")
    print(f"Test games:  {sorted(test_games)}")

    def split_for_game(gid: str) -> str:
        if gid in train_games:
            return "train"
        if gid in val_games:
            return "val"
        return "test"

    manifest["split"] = manifest["game_id"].apply(split_for_game)
    manifest = manifest.sample(frac=1.0, random_state=seed).reset_index(drop=True)

    n_train = (manifest["split"] == "train").sum()
    n_val = (manifest["split"] == "val").sum()
    n_test = (manifest["split"] == "test").sum()

    manifest_path = os.path.join(out_root, "dataset_manifest.csv")
    manifest.to_csv(manifest_path, index=False)
    
    print(f"\nWrote manifest: {manifest_path}")
    print(f"  Train: {n_train:,} squares from {len(train_games)} games")
    print(f"  Val:   {n_val:,} squares from {len(val_games)} games")
    print(f"  Test:  {n_test:,} squares from {len(test_games)} games")
    print(f"  Total: {len(manifest):,} squares")
    
    return manifest


def parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="Build dataset manifest with game-level split")
    ap.add_argument("--data_root", default="Data", help="Root folder with game subfolders")
    ap.add_argument("--out_root", default="dataset_out", help="Output folder")
    ap.add_argument("--train_ratio", type=float, default=0.6, help="Train split ratio (default: 0.6)")
    ap.add_argument("--val_ratio", type=float, default=0.2, help="Val split ratio (default: 0.2)")
    ap.add_argument("--seed", type=int, default=42, help="Random seed")
    ap.add_argument("--detect_board", action="store_true", help="Run board detection")
    ap.add_argument("--warp_size", type=int, default=800, help="Warp output size")
    ap.add_argument("--skip_missing", action="store_true", default=True, help="Skip missing frames")
    ap.add_argument("--no-skip-missing", dest="skip_missing", action="store_false")
    return ap.parse_args()


def main() -> None:
    args = parse_args()
    build_manifest(
        args.data_root,
        args.out_root,
        args.train_ratio,
        args.val_ratio,
        skip_missing=args.skip_missing,
        seed=args.seed,
        detect_board=args.detect_board,
        warp_size=args.warp_size,
    )


if __name__ == "__main__":
    main()